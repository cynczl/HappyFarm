package com.example.happyfarm;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper extends SQLiteOpenHelper {
    private static final String name = "database.db";	//���ݿ�����
    private static final int version = 1;				//���ݿ�汾

    public DBOpenHelper(Context context) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    	db.execSQL("CREATE TABLE IF NOT EXISTS user(key integer primary key autoincrement, user_id varchar(60), user_money varchar(60))");
        db.execSQL("CREATE TABLE IF NOT EXISTS land(key integer primary key autoincrement, land_wet varchar(60), remain_time varchar(60),if_open varchar(60), if_plant varchar(60), plant_kind varchar(60))");
        db.execSQL("CREATE TABLE IF NOT EXISTS seed(key integer primary key autoincrement, seed_name varchar(60), seed_buyprice varchar(60),user_had varchar(60))");
        db.execSQL("CREATE TABLE IF NOT EXISTS plant(key integer primary key autoincrement, plant_name varchar(60), plant_product_num varchar(60),mature_time varchar(60), plant_sellprice varchar(60), user_had varchar(60))");
        db.execSQL("CREATE TABLE IF NOT EXISTS food(key integer primary key autoincrement, food_name varchar(60), food_sellprice varchar(60),user_had varchar(60))");
    }

  
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    	db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS land");
        db.execSQL("DROP TABLE IF EXISTS seed");
        db.execSQL("DROP TABLE IF EXISTS plant");
        db.execSQL("DROP TABLE IF EXISTS food");
        onCreate(db);
        
    }
    


}