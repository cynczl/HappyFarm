package com.example.happyfarm;

import android.content.Context;
import android.database.Cursor;


//���ݿⷽ������ɾ���
public class DatabaseService {
    private DBOpenHelper dbOpenHelper;
    /**
     * ͨ�����췽����ʵ����DBOpenHelper
     * */
    public DatabaseService(Context context) {
        dbOpenHelper = new DBOpenHelper(context);
    }  
    public void dropTable(String taleName) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "DROP TABLE IF EXISTS " + taleName);
    }
    
    /**
     * �ر�ָ���ı�
     * */
    public void closeDatabase(String DatabaseName) {
        dbOpenHelper.getWritableDatabase().close();
                
    }
    
    /**
     * ����user����land����seed����plant����food��
     * */
    public void createUserTable() {
        String sql = "CREATE TABLE IF NOT EXISTS user(key varchar(60), user_id varchar(60), user_money varchar(60))";
        dbOpenHelper.getWritableDatabase().execSQL(sql);
    }
    public void createLandTable() {
        String sql = "CREATE TABLE IF NOT EXISTS land(key integer primary key autoincrement, land_wet varchar(60), remain_time varchar(60), if_open varchar(60), if_plant varchar(60), plant_kind varchar(60))";
        dbOpenHelper.getWritableDatabase().execSQL(sql);
    }
    public void createSeedTable() {
        String sql = "CREATE TABLE IF NOT EXISTS seed(key integer primary key autoincrement, seed_name varchar(60), seed_buyprice varchar(60),user_had varchar(60))";
        dbOpenHelper.getWritableDatabase().execSQL(sql);
    }
    public void createPlantTable() {
        String sql = "CREATE TABLE IF NOT EXISTS plant(key integer primary key autoincrement, plant_name varchar(60), plant_product_num varchar(60),mature_time varchar(60), plant_sellprice varchar(60), user_had varchar(60))";
        dbOpenHelper.getWritableDatabase().execSQL(sql);
    }
    public void createFooddTable() {
        String sql = "CREATE TABLE IF NOT EXISTS food(key integer primary key autoincrement, food_name varchar(60), food_sellprice varchar(60),user_had varchar(60))";
        dbOpenHelper.getWritableDatabase().execSQL(sql);
    }
    
    /**
     * ������Ϣ��������
     * */
    public void saveUserInfo(User user) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "insert into user (key, user_id, user_money) values(?,?,?)",
                new Object[] { user.get_key(), user.get_id(), user.get_money() });
    }
    public void saveLandInfo(Land land) {
        dbOpenHelper.getWritableDatabase().execSQL(
        		"insert into land (key,land_wet,remain_time,if_open,if_plant,plant_kind) values(?,?,?,?,?,?)",
        		new Object[] { land.get_key(), land.get_landwet(),land.get_remaintime(), land.get_ifopen(), land.get_ifplant(), land.get_plantkind() });
    }
    public void saveSeedInfo(Seed seed) {
    	dbOpenHelper.getWritableDatabase().execSQL(
    			"insert into seed (key,seed_name,seed_buyprice,user_had) values(?,?,?,?)",
    			new Object[] { seed.get_key(), seed.get_name(), seed.get_buyprice(), seed.get_userhad() });
    }
    public void savePlantInfo(Plant plant) {
    	dbOpenHelper.getWritableDatabase().execSQL(
    			"insert into plant (key,plant_name,plant_product_num,mature_time,plant_sellprice,user_had) values(?,?,?,?,?,?)",
    			new Object[] { plant.get_key(), plant.get_name(), plant.get_productnum(), plant.get_maturetime(), plant.get_sellprice(), plant.get_userhad() });
    }
    public void saveFoodInfo(Food food) {
    	dbOpenHelper.getWritableDatabase().execSQL(
    			"insert into food (key,food_name,food_sellprice,user_had) values(?,?,?,?)",
    			new Object[] { food.get_key(), food.get_name(), food.get_sellprice(), food.get_userhad() });
    }
      
    /**
     * �޸ı���ָ���е���Ϣ
     * */
    public void updateUserInfo(User user) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "update user set user_id=?, user_money=? where key=?",
                new Object[] { user.get_id(), user.get_money(), user.get_key() });
    }
    public void updateLandInfo(Land land) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "update land set land_wet=?, remain_time=?, if_open=?, if_plant=?, plant_kind=? where key=?",
                new Object[] { land.get_landwet(), land.get_remaintime(), land.get_ifopen(), land.get_ifplant(), land.get_plantkind(), land.get_key() });
    }
    public void updateSeedInfo(Seed seed) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "update seed set seed_name=?, seed_buyprice=?, user_had=? where key=?",
                new Object[] { seed.get_name(), seed.get_buyprice(), seed.get_userhad(), seed.get_key() });
    }
    public void updatePlantInfo(Plant plant) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "update plant set plant_name=?, plant_product_num=?, mature_time=?, plant_sellprice=?, user_had=? where key=?",
                new Object[] { plant.get_name(), plant.get_productnum(), plant.get_maturetime(), plant.get_sellprice(), plant.get_userhad(), plant.get_key() });
    }
    public void updateFoodInfo(Food food) {
        dbOpenHelper.getWritableDatabase().execSQL(
                "update food set food_name=?, food_sellprice=?, user_had=? where key=?",
                new Object[] { food.get_name(), food.get_sellprice(), food.get_userhad(), food.get_key() });
    }
    
    
    
    /**
     * ɾ��ָ�����е�ָ����key��Ϣ
     * */
    public void deleteItemData(String tableName, Integer key) {
        dbOpenHelper.getWritableDatabase()
                .execSQL("delete from " + tableName + " where key=?",
                        new Object[] { key });
    }

    /**
     * ���ұ����Ƿ����ָ��key����Ϣ,���򷵻ظñ���û�з���null
     * */
    public User findUserInfo(Integer key) {
        Cursor cursor = dbOpenHelper.getWritableDatabase().rawQuery(
                "select key,user_id,user_money from user where key=?",
                new String[] { String.valueOf(key) });
        if (cursor.moveToNext()) {
            User userInfo = new User();
            userInfo.set_key((cursor.getInt(0)));
            userInfo.set_id(cursor.getString(1));
            userInfo.set_money(cursor.getInt(2));
            return userInfo;
        }
        return null;
    }
    public Land findLandInfo(Integer key) {
        Cursor cursor = dbOpenHelper.getWritableDatabase().rawQuery(
                "select key,land_wet,remain_time,if_open,if_plant,plant_kind from land where key=?",
                new String[] { String.valueOf(key) });
        if (cursor.moveToNext()) {
            Land landInfo = new Land();
            landInfo.set_key((cursor.getInt(0)));
            landInfo.set_landwet(cursor.getInt(1));
            landInfo.set_remaintime(cursor.getInt(2));
            landInfo.set_ifopen(cursor.getInt(3));
            landInfo.set_ifplant(cursor.getInt(4));
            landInfo.set_plantkind(cursor.getInt(5));
            return landInfo;
        }
        return null;
    }
    public Seed findSeedInfo(Integer key) {
        Cursor cursor = dbOpenHelper.getWritableDatabase().rawQuery(
                "select key,seed_name,seed_buyprice,user_had from seed where key=?",
                new String[] { String.valueOf(key) });
        if (cursor.moveToNext()) {
            Seed seedInfo = new Seed();
            seedInfo.set_key((cursor.getInt(0)));
            seedInfo.set_name(cursor.getString(1));
            seedInfo.set_buyprice(cursor.getInt(2));
            seedInfo.set_userhad(cursor.getInt(3));
            return seedInfo;
        }
        return null;
    }
    public Plant findPlantInfo(Integer key) {
        Cursor cursor = dbOpenHelper.getWritableDatabase().rawQuery(
                "select key,plant_name,plant_product_num,mature_time,plant_sellprice,user_had from plant where key=?",
                new String[] { String.valueOf(key) });
        if (cursor.moveToNext()) {
            Plant plantInfo = new Plant();
            plantInfo.set_key((cursor.getInt(0)));
            plantInfo.set_name(cursor.getString(1));
            plantInfo.set_productnum(cursor.getInt(2));
            plantInfo.set_maturetime(cursor.getInt(3));
            plantInfo.set_sellprice(cursor.getInt(4));
            plantInfo.set_userhad(cursor.getInt(5));
            return plantInfo;
        }
        return null;
    }
    public Food findFoodInfo(Integer key) {
        Cursor cursor = dbOpenHelper.getWritableDatabase().rawQuery(
                "select key,food_name,food_sellprice,user_had from food where key=?",
                new String[] { String.valueOf(key) });
        if (cursor.moveToNext()) {
            Food foodInfo = new Food();
            foodInfo.set_key((cursor.getInt(0)));
            foodInfo.set_name(cursor.getString(1));
            foodInfo.set_sellprice(cursor.getInt(2));
            foodInfo.set_userhad(cursor.getInt(3));
            return foodInfo;
        }
        return null;
    }
     
    /**
     * ����ָ�����Ĵ�С
     * */
    public long getDataCount(String tableName) {
        Cursor cursor = dbOpenHelper.getReadableDatabase().rawQuery(
                "select count(*) from " + tableName, null);
        cursor.moveToFirst();
        return cursor.getLong(0);
    }

    public void close() {
        dbOpenHelper.close();
    }

}