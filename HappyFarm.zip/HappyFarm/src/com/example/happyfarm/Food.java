package com.example.happyfarm;

public class Food {
	private int key;
	private String food_name;
	private int food_sellprice;
	private int user_had;
	
	public int get_key(){
		return key;
	}
	public void set_key(int num){
		this.key = num;
	}
	public String get_name(){
		return food_name;
	}
	public void set_name(String str){
		this.food_name = str;
	}
	public int get_sellprice(){
		return food_sellprice;
	}
	public void set_sellprice(int price){
		this.food_sellprice = price;
	}
	public int get_userhad(){
		return user_had;
	}
	public void set_userhad(int num){
		this.user_had = num;
	}
}
