package com.example.happyfarm;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.format.Time;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class GameMapActivity extends Activity {
	Context context;
	private static GameMapActivity gamemapactivity;
	public static GameMapActivity get_obj(){
		return gamemapactivity;
	}
	
	private User user;
	private Plant plant;
	private Seed seed;
	private Land land;

	private int flag_harvest=0;
	private int flag_water=0;
	private int flag_spade=0;
	
	private int num_earth=0;
	private int num_plant=0;
	
	private TextView tv_time;
	private TextView tv_wet;
	
	private ImageView imageview_bg1;
	private ImageView imageview_bg2;
	private ImageView imageview_bg3;
	
	private ImageView imageview_earth_1;
	private ImageView imageview_earth_2;
	private ImageView imageview_earth_3;
	private ImageView imageview_earth_4;
	private ImageView imageview_earth_5;
	private ImageView imageview_earth_6;
	private ImageView imageview_earth_7;
	private ImageView imageview_earth_8;
	private ImageView imageview_earth_9;
	private ImageView imageview_earth_10;
	private ImageView imageview_earth_11;
	private ImageView imageview_earth_12;
	
	private ImageView imageview_plant_1;
	private ImageView imageview_plant_2;
	private ImageView imageview_plant_3;
	private ImageView imageview_plant_4;
	private ImageView imageview_plant_5;
	private ImageView imageview_plant_6;
	private ImageView imageview_plant_7;
	private ImageView imageview_plant_8;
	private ImageView imageview_plant_9;
	private ImageView imageview_plant_10;
	private ImageView imageview_plant_11;
	private ImageView imageview_plant_12;
	
	private ImageView imageview_small_apple;
	private ImageView imageview_small_peach;
	private ImageView imageview_small_watermelon;
	private ImageView imageview_small_shiliu;
	private ImageView imageview_small_rose;
	
	private TextView imageview_tv;
	private ImageView imageview_shop;
	private ImageView imageview_home;
	private ImageView imageview_factory;
	private ImageView imageview_btn_right;
	private ImageView imageview_borad_right;
	private ImageView imageview_hand;
	private ImageView imageview_water;
	private ImageView imageview_spade;
	private ImageView imageview_btn_right_a;
	private TextView imageview_name;
	
	private DatabaseService ds; 
	
	private int speed_x;
	private int speed_x_b;
	
	private int btn_cur_x=0;
	private int btn_next_x=0;
	
	private int borad_cur_x=0;
	private int borad_next_x=0;
	
	private int hand_cur_x=0;
	private int hand_next_x=0;
	
	private int water_cur_x=0;
	private int water_next_x=0;
	
	private int spade_cur_x=0;
	private int spade_next_x=0;
	
	//��FLAG=1ʱ�˵���ʾ��-1��ʱ����ʾ
	private int flag_btn_right;
	//0Ϊû�а��£�1Ϊ����
	private int flag_btn_right_press;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//ȥ�����ںͱ���
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        //ȫ����ʾ
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //���ú���
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setContentView(R.layout.activity_game_map);
		
		if(WellcomeActivity.get_obj()!=null){
			WellcomeActivity.get_obj().finish();
		}
		if(ShopActivity.get_obj()!=null){
			ShopActivity.get_obj().finish();
		}
		if(HomeActivity.get_obj()!=null){
			HomeActivity.get_obj().finish();
		}
		
	
		
		context=GameMapActivity.this;
		ds = new DatabaseService(context);
		ds.createUserTable();
		user=ds.findUserInfo(1);
		
		tv_time=(TextView)findViewById(R.id.tv_time);
		tv_wet=(TextView)findViewById(R.id.tv_wet);
		
		imageview_bg1=(ImageView)findViewById(R.id.back_bg1);
		imageview_bg2=(ImageView)findViewById(R.id.back_bg2);
		imageview_bg3=(ImageView)findViewById(R.id.back_bg3);
		imageview_bg1.setAlpha(0f);
		imageview_bg2.setAlpha(0f);
		imageview_bg3.setAlpha(0f);
		
		init_view();
		init_data();
		showtime();
		setonclick();
		set_unplant();
		init_earth();
		
		CharSequence cs=String.valueOf(user.get_money());
		
		
		final Handler handler=new Handler()
		{
			@Override
			public void handleMessage(Message msg)
			{
				//��ʾʱ��
				if(msg.what==0x111){
					showtime();
				}
				//�Ҳ˵��ƶ�
				if(msg.what==0x222){
					if(flag_btn_right==1)
						speed_x_b=30;
					else if(flag_btn_right==-1)
						speed_x_b=-30;
					
					if(speed_x_b>0&&borad_next_x>=120){
						flag_btn_right_press=0;
						speed_x_b=0;
					}
					if(speed_x_b<0&&borad_next_x<=0){
						flag_btn_right_press=0;
						speed_x_b=0;
					}
					borad_next_x=borad_cur_x+speed_x_b;
					TranslateAnimation anim_borad=new TranslateAnimation(borad_cur_x,borad_next_x,0,0);
					borad_cur_x=borad_next_x;
					anim_borad.setFillAfter(true);
					anim_borad.setDuration(200);
					
					imageview_borad_right.startAnimation(anim_borad);
					imageview_hand.startAnimation(anim_borad);
					imageview_water.startAnimation(anim_borad);
					imageview_spade.startAnimation(anim_borad);
					imageview_btn_right.startAnimation(anim_borad);
					
				}
				if(msg.what==0x121){
					land=ds.findLandInfo(1);
					stage_seed(land,ds,imageview_plant_1);
					land=ds.findLandInfo(2);
					stage_seed(land,ds,imageview_plant_2);
					land=ds.findLandInfo(3);
					stage_seed(land,ds,imageview_plant_3);
					land=ds.findLandInfo(4);
					stage_seed(land,ds,imageview_plant_4);
					land=ds.findLandInfo(5);
					stage_seed(land,ds,imageview_plant_5);
					land=ds.findLandInfo(6);
					stage_seed(land,ds,imageview_plant_6);
					land=ds.findLandInfo(7);
					stage_seed(land,ds,imageview_plant_7);
					land=ds.findLandInfo(8);
					stage_seed(land,ds,imageview_plant_8);
					land=ds.findLandInfo(9);
					stage_seed(land,ds,imageview_plant_9);
					land=ds.findLandInfo(10);
					stage_seed(land,ds,imageview_plant_10);
					land=ds.findLandInfo(11);
					stage_seed(land,ds,imageview_plant_11);
					land=ds.findLandInfo(12);
					stage_seed(land,ds,imageview_plant_12);
				}
				
				if(msg.what==0x122){
					if(num_plant!=0){
						land=ds.findLandInfo(num_plant);
						tv_time.setText(null);
						tv_wet.setText(null);
						tv_time.setText(String.valueOf(land.get_remaintime())+"s");
						tv_wet.setText(String.valueOf(land.get_landwet())+"%");
					}
				}

			}
		};
		
		new Timer().schedule(new TimerTask(){
			@Override
			public void run(){
				//����ʱ��
				handler.sendEmptyMessage(0x111);
				//�Ҳ˵��ƶ�
				if(flag_btn_right_press==1){
					handler.sendEmptyMessage(0x222);
				}
				
			}
		}, 0,50);
		new Timer().schedule(new TimerTask(){
			@Override
			public void run(){
				
				handler.sendEmptyMessage(0x121);
				handler.sendEmptyMessage(0x122);
			}
		}, 0,1000);
	}
	//���ð���
	public void setonclick(){
		imageview_spade.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				set_unplant();
				if(flag_spade==0){
					Toast.makeText(getApplicationContext(), "��ѡ����Ҫ���ѵ�����,�ٴΰ��¿���ȡ���ջ�״̬", 200).show();
					flag_spade=1;
					imageview_bg3.setAlpha(1f);
					set_unpress(imageview_shop);
					set_unpress(imageview_home);
					set_unpress(imageview_factory);
					set_unpress(imageview_water);
					set_unpress(imageview_hand);
				}
				else {
					Toast.makeText(getApplicationContext(), "����״̬ȡ��", 200).show();
					flag_spade=0;
					imageview_bg3.setAlpha(0f);
					set_press(imageview_shop);
					set_press(imageview_home);
					set_press(imageview_factory);
					set_press(imageview_water);
					set_press(imageview_hand);
				}
			}
			
		});
		imageview_earth_1.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(1);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=1;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=1;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
			else if(flag_harvest==1){
				land=ds.findLandInfo(1);
				if(land.get_ifplant()==1&&land.get_remaintime()==0){
					imageview_plant_1.setImageDrawable(null);
					plant=ds.findPlantInfo(land.get_plantkind());
					land.set_ifplant(0);
					land.set_landwet(100);
					land.set_plantkind(0);
					land.set_remaintime(0);
					ds.updateLandInfo(land);
					plant.set_userhad(plant.get_userhad()+plant.get_productnum());
					ds.updatePlantInfo(plant);
				}
				else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
			}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(1);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
		}
			
	});
		imageview_earth_2.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(2);
				if(land.get_ifopen()==1){
					num_plant=2;
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=2;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(2);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_2.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(2);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_3.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(3);
				if(land.get_ifopen()==1){
					
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=3;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=3;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(3);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_3.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(3);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_4.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(4);
				if(land.get_ifopen()==1){
					
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=4;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=4;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(4);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_4.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(4);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_5.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(5);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=5;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=5;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(5);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_5.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(5);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_6.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(6);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=6;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=6;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(6);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_6.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(6);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_7.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(7);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=7;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=7;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(7);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_7.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(7);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-4);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_8.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(8);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=8;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=8;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(8);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_8.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(8);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_9.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(9);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=9;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=9;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(9);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_9.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(9);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
			}
		});
		imageview_earth_10.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_spade==0){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(10);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=10;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=10;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(10);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_10.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(10);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
				}
				else if(flag_spade==1){
					land=ds.findLandInfo(10);
					user=ds.findUserInfo(1);
					if(land.get_ifopen()==1)
						Toast.makeText(getApplicationContext(), "�����Ѿ����ѹ���", 200).show();
					else{
						if(user.get_money()>=50){
							user.set_money(user.get_money()-50);
							land.set_ifopen(1);
							imageview_earth_10.setImageResource(R.drawable.earth1);
							ds.updateLandInfo(land);
							ds.updateUserInfo(user);
						}
						else Toast.makeText(getApplicationContext(), "Ǯ����!", 200).show();
					}
				}
			}
		});
		imageview_earth_11.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_spade==0){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(11);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=11;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=11;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(11);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_11.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(11);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
				}
				else if(flag_spade==1){
					land=ds.findLandInfo(11);
					user=ds.findUserInfo(1);
					if(land.get_ifopen()==1)
						Toast.makeText(getApplicationContext(), "�����Ѿ����ѹ���", 200).show();
					else{
						if(user.get_money()>=50){
							user.set_money(user.get_money()-50);
							land.set_ifopen(1);
							imageview_earth_11.setImageResource(R.drawable.earth1);
							ds.updateLandInfo(land);
							ds.updateUserInfo(user);
						}
						else Toast.makeText(getApplicationContext(), "Ǯ����!", 200).show();
					}
				}
			}
		});
		imageview_earth_12.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				if(flag_spade==0){
				if(flag_water==0){
				if(flag_harvest==0){
				land=ds.findLandInfo(12);
				if(land.get_ifopen()==1){
					//��ʾ��ֲ����Ϣ
					if(land.get_ifplant()==1){
						num_plant=12;
						set_unplant();
						switch(land.get_plantkind()){
						case 1: imageview_name.setText(null);
								imageview_name.setText("ƻ��");
								break;
						case 2: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 3: imageview_name.setText(null);
								imageview_name.setText("����");
								break;
						case 4: imageview_name.setText(null);
								imageview_name.setText("ʯ��");
								break;
						case 5: imageview_name.setText(null);
								imageview_name.setText("õ��");
								break;
						}
					}
					//��ʾ���ؿ�ȱ״��
					//��ʾ��ֲ
					else{
						set_plant();
						num_earth=12;
						imageview_name.setText(null);
						imageview_name.setText("��������ֲ!");
					}
					
				}
				else Toast.makeText(getApplicationContext(), "�׻�˵���¸������������������ؿ�������", 200).show();
			}
				else if(flag_harvest==1){
					land=ds.findLandInfo(12);
					if(land.get_ifplant()==1&&land.get_remaintime()==0){
						imageview_plant_12.setImageDrawable(null);
						plant=ds.findPlantInfo(land.get_plantkind());
						land.set_ifplant(0);
						land.set_landwet(100);
						land.set_plantkind(0);
						land.set_remaintime(0);
						ds.updateLandInfo(land);
						plant.set_userhad(plant.get_userhad()+plant.get_productnum());
						ds.updatePlantInfo(plant);
					}
					else Toast.makeText(getApplicationContext(), "����ʣ��ʱ�䵽0�����ջ�Ŷ", 200).show();
				}
				}
				else if(flag_water==1){
					land=ds.findLandInfo(12);
					user=ds.findUserInfo(1);
					if(land.get_ifplant()==1&&user.get_money()>=4){
						land.set_landwet(land.get_landwet()+35);
						user.set_money(user.get_money()-1);
						ds.updateLandInfo(land);
						ds.updateUserInfo(user);
						Toast.makeText(getApplicationContext(), "��ˮ�ɹ�", 200).show();
					}
					else if(land.get_ifplant()==0)
						Toast.makeText(getApplicationContext(), "������ֲ����˵", 200).show();
					else if(user.get_money()<4)
						Toast.makeText(getApplicationContext(), "�����û��Ǯ��Ŷ", 200).show();
				}
				}
				else if(flag_spade==1){
					land=ds.findLandInfo(12);
					user=ds.findUserInfo(1);
					if(land.get_ifopen()==1)
						Toast.makeText(getApplicationContext(), "�����Ѿ����ѹ���", 200).show();
					else{
						if(user.get_money()>=50){
							user.set_money(user.get_money()-50);
							land.set_ifopen(1);
							imageview_earth_12.setImageResource(R.drawable.earth1);
							ds.updateLandInfo(land);
							ds.updateUserInfo(user);
						}
						else Toast.makeText(getApplicationContext(), "Ǯ����!", 200).show();
					}
				}
			}
		});
		
		imageview_shop.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				Intent intent =new Intent(GameMapActivity.this,ShopActivity.class);
				startActivity(intent);
				//finish();
			}
		});
		imageview_home.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				Intent intent1 =new Intent(GameMapActivity.this,HomeActivity.class);
				startActivity(intent1);
		//		finish();
			}
		});
		imageview_factory.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				Toast.makeText(getApplicationContext(), "������δ����", 200).show();
			}
		});
		imageview_btn_right.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				set_unpress(imageview_btn_right);
				set_press(imageview_btn_right_a);
				set_unpress(imageview_hand);
				set_unpress(imageview_water);
				set_unpress(imageview_spade);
					flag_btn_right=1;
					
		
				flag_btn_right_press=1;
			}
		});
		imageview_btn_right_a.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				
				set_unpress(imageview_btn_right_a);
				set_press(imageview_btn_right);
				set_press(imageview_hand);
				set_press(imageview_water);
				set_press(imageview_spade);
			
				flag_btn_right=-1;
		
				flag_btn_right_press=1;
			}
		});
		imageview_small_apple.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				//
				
				switch(num_earth){
				case 1: plant_small(imageview_plant_1, num_earth, 1);
						break;
				case 2: plant_small(imageview_plant_2, num_earth, 1);
						break;
				case 3: plant_small(imageview_plant_3, num_earth, 1);
						break;
				case 4: plant_small(imageview_plant_4, num_earth, 1);
						break;
				case 5: plant_small(imageview_plant_5, num_earth, 1);
						break;
				case 6: plant_small(imageview_plant_6, num_earth, 1);
						break;
				case 7: plant_small(imageview_plant_7, num_earth, 1);
						break;
				case 8: plant_small(imageview_plant_8, num_earth, 1);
						break;
				case 9: plant_small(imageview_plant_9, num_earth, 1);
						break;
				case 10: plant_small(imageview_plant_10, num_earth, 1);
						break;
				case 11: plant_small(imageview_plant_11, num_earth, 1);
						break;
				case 12: plant_small(imageview_plant_12, num_earth, 1);
						break;
				}
			}
		});
		imageview_small_peach.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				//
				
				switch(num_earth){
				case 1: plant_small(imageview_plant_1, num_earth, 2);
						break;
				case 2: plant_small(imageview_plant_2, num_earth, 2);
						break;
				case 3: plant_small(imageview_plant_3, num_earth, 2);
						break;
				case 4: plant_small(imageview_plant_4, num_earth, 2);
						break;
				case 5: plant_small(imageview_plant_5, num_earth, 2);
						break;
				case 6: plant_small(imageview_plant_6, num_earth, 2);
						break;
				case 7: plant_small(imageview_plant_7, num_earth, 2);
						break;
				case 8: plant_small(imageview_plant_8, num_earth, 2);
						break;
				case 9: plant_small(imageview_plant_9, num_earth, 2);
						break;
				case 10: plant_small(imageview_plant_10, num_earth, 2);
						break;
				case 11: plant_small(imageview_plant_11, num_earth, 2);
						break;
				case 12: plant_small(imageview_plant_12, num_earth, 2);
						break;
				}
			}
		});
		imageview_small_watermelon.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				//
				
				switch(num_earth){
				case 1: plant_small(imageview_plant_1, num_earth, 3);
						break;
				case 2: plant_small(imageview_plant_2, num_earth, 3);
						break;
				case 3: plant_small(imageview_plant_3, num_earth, 3);
						break;
				case 4: plant_small(imageview_plant_4, num_earth, 3);
						break;
				case 5: plant_small(imageview_plant_5, num_earth, 3);
						break;
				case 6: plant_small(imageview_plant_6, num_earth, 3);
						break;
				case 7: plant_small(imageview_plant_7, num_earth, 3);
						break;
				case 8: plant_small(imageview_plant_8, num_earth, 3);
						break;
				case 9: plant_small(imageview_plant_9, num_earth, 3);
						break;
				case 10: plant_small(imageview_plant_10, num_earth, 3);
						break;
				case 11: plant_small(imageview_plant_11, num_earth, 3);
						break;
				case 12: plant_small(imageview_plant_12, num_earth, 3);
						break;
				}
			}
		});
		imageview_small_shiliu.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				//
				
				switch(num_earth){
				case 1: plant_small(imageview_plant_1, num_earth, 4);
						break;
				case 2: plant_small(imageview_plant_2, num_earth, 4);
						break;
				case 3: plant_small(imageview_plant_3, num_earth, 4);
						break;
				case 4: plant_small(imageview_plant_4, num_earth, 4);
						break;
				case 5: plant_small(imageview_plant_5, num_earth, 4);
						break;
				case 6: plant_small(imageview_plant_6, num_earth, 4);
						break;
				case 7: plant_small(imageview_plant_7, num_earth, 4);
						break;
				case 8: plant_small(imageview_plant_8, num_earth, 4);
						break;
				case 9: plant_small(imageview_plant_9, num_earth, 4);
						break;
				case 10: plant_small(imageview_plant_10, num_earth, 4);
						break;
				case 11: plant_small(imageview_plant_11, num_earth, 4);
						break;
				case 12: plant_small(imageview_plant_12, num_earth, 4);
						break;
				}
			}
		});
		imageview_small_rose.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				//
				
				switch(num_earth){
				case 1: plant_small(imageview_plant_1, num_earth, 5);
						break;
				case 2: plant_small(imageview_plant_2, num_earth, 5);
						break;
				case 3: plant_small(imageview_plant_3, num_earth, 5);
						break;
				case 4: plant_small(imageview_plant_4, num_earth, 5);
						break;
				case 5: plant_small(imageview_plant_5, num_earth, 5);
						break;
				case 6: plant_small(imageview_plant_6, num_earth, 5);
						break;
				case 7: plant_small(imageview_plant_7, num_earth, 5);
						break;
				case 8: plant_small(imageview_plant_8, num_earth, 5);
						break;
				case 9: plant_small(imageview_plant_9, num_earth, 5);
						break;
				case 10: plant_small(imageview_plant_10, num_earth, 5);
						break;
				case 11: plant_small(imageview_plant_11, num_earth, 5);
						break;
				case 12: plant_small(imageview_plant_12, num_earth, 5);
						break;
				}
			}
		});
		imageview_hand.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				set_unplant();
				if(flag_harvest==0){
					Toast.makeText(getApplicationContext(), "��ѡ����Ҫ�ջ��ֲ��,�ٴΰ��¿���ȡ���ջ�״̬", 200).show();
					flag_harvest=1;
					imageview_bg1.setAlpha(1f);
					set_unpress(imageview_shop);
					set_unpress(imageview_home);
					set_unpress(imageview_factory);
					set_unpress(imageview_water);
					set_unpress(imageview_spade);
				}
				else {
					Toast.makeText(getApplicationContext(), "�ջ�״̬ȡ��", 200).show();
					flag_harvest=0;
					imageview_bg1.setAlpha(0f);
					set_press(imageview_shop);
					set_press(imageview_home);
					set_press(imageview_factory);
					set_press(imageview_water);
					set_press(imageview_spade);
				}
			}
		});
		imageview_water.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				set_unplant();
				if(flag_water==0){
					Toast.makeText(getApplicationContext(), "��ѡ����Ҫ��ˮ��ֲ��,�ٴΰ��¿���ȡ���ջ�״̬", 200).show();
					flag_water=1;
					imageview_bg2.setAlpha(1f);
					set_unpress(imageview_shop);
					set_unpress(imageview_home);
					set_unpress(imageview_factory);
					set_unpress(imageview_hand);
					set_unpress(imageview_spade);
				}
				else {
					Toast.makeText(getApplicationContext(), "��ˮ״̬ȡ��", 200).show();
					flag_water=0;
					imageview_bg2.setAlpha(0f);
					set_press(imageview_shop);
					set_press(imageview_home);
					set_press(imageview_factory);
					set_press(imageview_hand);
					set_press(imageview_spade);
				}
			}
		});
	}
	
	public void showtime(){
	
		Time time = new Time("GMT"); 
		time.setToNow();     
		int hour = time.hour+8;      
	    int minute = time.minute;      
	    int sec = time.second;
	    imageview_tv.setText(null);

	   
	    imageview_tv.setText(        
                 hour +       
                ":" + minute +       
                ": " + sec      
                );      
	}
	public void init_view(){
	    
        imageview_plant_1=(ImageView)findViewById(R.id.plant_1);
        imageview_plant_2=(ImageView)findViewById(R.id.plant_2);
        imageview_plant_3=(ImageView)findViewById(R.id.plant_3);
        imageview_plant_4=(ImageView)findViewById(R.id.plant_4);
        imageview_plant_5=(ImageView)findViewById(R.id.plant_5);
        imageview_plant_6=(ImageView)findViewById(R.id.plant_6);
        imageview_plant_7=(ImageView)findViewById(R.id.plant_7);
        imageview_plant_8=(ImageView)findViewById(R.id.plant_8);
        imageview_plant_9=(ImageView)findViewById(R.id.plant_9);
        imageview_plant_10=(ImageView)findViewById(R.id.plant_10);
        imageview_plant_11=(ImageView)findViewById(R.id.plant_11);
        imageview_plant_12=(ImageView)findViewById(R.id.plant_12);
		
		imageview_earth_1=(ImageView)findViewById(R.id.earth_1);
		imageview_earth_2=(ImageView)findViewById(R.id.earth_2);
		imageview_earth_3=(ImageView)findViewById(R.id.earth_3);
		imageview_earth_4=(ImageView)findViewById(R.id.earth_4);
		imageview_earth_5=(ImageView)findViewById(R.id.earth_5);
		imageview_earth_6=(ImageView)findViewById(R.id.earth_6);
		imageview_earth_7=(ImageView)findViewById(R.id.earth_7);
		imageview_earth_8=(ImageView)findViewById(R.id.earth_8);
		imageview_earth_9=(ImageView)findViewById(R.id.earth_9);
		imageview_earth_10=(ImageView)findViewById(R.id.earth_10);
		imageview_earth_11=(ImageView)findViewById(R.id.earth_11);
		imageview_earth_12=(ImageView)findViewById(R.id.earth_12);
		
		imageview_small_apple=(ImageView)findViewById(R.id.small_apple);
		
		imageview_small_peach=(ImageView)findViewById(R.id.small_peach);
		
		imageview_small_watermelon=(ImageView)findViewById(R.id.small_watermelon);
		
		imageview_small_shiliu=(ImageView)findViewById(R.id.small_shiliu);
		
		imageview_small_rose=(ImageView)findViewById(R.id.small_rose);
		
		
		imageview_tv=(TextView)findViewById(R.id.tv);
	
		imageview_shop=(ImageView)findViewById(R.id.shop);
		imageview_home=(ImageView)findViewById(R.id.home);
		imageview_factory=(ImageView)findViewById(R.id.factory);
		imageview_btn_right=(ImageView)findViewById(R.id.btn_right);
		imageview_borad_right=(ImageView)findViewById(R.id.borad_right);
		imageview_hand=(ImageView)findViewById(R.id.hand);
		imageview_water=(ImageView)findViewById(R.id.water);
		imageview_spade=(ImageView)findViewById(R.id.spade);
		imageview_btn_right_a=(ImageView)findViewById(R.id.btn_right_a);
		imageview_btn_right_a.setAlpha(0f);
		imageview_name=(TextView)findViewById(R.id.board_name);
		set_unpress(imageview_btn_right_a);
		
	}
	
	public void init_data(){
		gamemapactivity=this;
		speed_x=30;
		flag_btn_right=1;
		flag_btn_right_press=0;
	     set_plant_null(imageview_plant_1);
	        set_plant_null(imageview_plant_2);
	        set_plant_null(imageview_plant_3);
	        set_plant_null(imageview_plant_4);
	        set_plant_null(imageview_plant_5);
	        set_plant_null(imageview_plant_6);
	        set_plant_null(imageview_plant_7);
	        set_plant_null(imageview_plant_8);
	        set_plant_null(imageview_plant_9);
	        set_plant_null(imageview_plant_10);
	        set_plant_null(imageview_plant_11);
	        set_plant_null(imageview_plant_12);
	}

	public void set_unpress(ImageView iv){
		iv.setPressed(false);
		iv.setClickable(false);
	}
	public void set_press(ImageView iv){
		iv.setPressed(true);
		iv.setClickable(true);
	}
	public void set_unplant(){
		imageview_small_apple.setAlpha(0f);
		set_unpress(imageview_small_apple);
		imageview_small_peach.setAlpha(0f);
		set_unpress(imageview_small_peach);
		imageview_small_watermelon.setAlpha(0f);
		set_unpress(imageview_small_watermelon);
		imageview_small_shiliu.setAlpha(0f);
		set_unpress(imageview_small_shiliu);
		imageview_small_rose.setAlpha(0f);
		set_unpress(imageview_small_rose);
	}
	public void set_plant(){
		imageview_small_apple.setAlpha(1f);
		set_press(imageview_small_apple);
		imageview_small_peach.setAlpha(1f);
		set_press(imageview_small_peach);
		imageview_small_watermelon.setAlpha(1f);
		set_press(imageview_small_watermelon);
		imageview_small_shiliu.setAlpha(1f);
		set_press(imageview_small_shiliu);
		imageview_small_rose.setAlpha(1f);
		set_press(imageview_small_rose);
	}
	public void set_plant_null(ImageView iv){
		iv.setImageDrawable(null);
	}
	
	public void plant_on_earth(ImageView iv, int key, int kind){
				land=ds.findLandInfo(key);
				plant=ds.findPlantInfo(kind);
				switch(kind){
				case 1:
						if(land.get_remaintime()>=0.7*plant.get_maturetime())
							iv.setImageResource(R.drawable.apple_1);
						else if(land.get_remaintime()<=0.2*plant.get_maturetime())
							iv.setImageResource(R.drawable.apple_3);
						else 
							iv.setImageResource(R.drawable.apple_2);
						break;
				case 2:
					if(land.get_remaintime()>=0.7*plant.get_maturetime())
						iv.setImageResource(R.drawable.peach_1);
					else if(land.get_remaintime()<=0.2*plant.get_maturetime())
						iv.setImageResource(R.drawable.peach_3);
					else 
						iv.setImageResource(R.drawable.peach_2);
					break;
				case 3:
					if(land.get_remaintime()>=0.7*plant.get_maturetime())
						iv.setImageResource(R.drawable.watermelon_1);
					else if(land.get_remaintime()<=0.2*plant.get_maturetime())
						iv.setImageResource(R.drawable.watermelon_3);
					else 
						iv.setImageResource(R.drawable.watermelon_2);
					break;
				case 4:
					if(land.get_remaintime()>=0.7*plant.get_maturetime())
						iv.setImageResource(R.drawable.shiliu_1);
					else if(land.get_remaintime()<=0.2*plant.get_maturetime())
						iv.setImageResource(R.drawable.shiliu_3);
					else 
						iv.setImageResource(R.drawable.shiliu_2);
					break;
				case 5:
					if(land.get_remaintime()>=0.7*plant.get_maturetime())
						iv.setImageResource(R.drawable.rose_1);
					else if(land.get_remaintime()<=0.2*plant.get_maturetime())
						iv.setImageResource(R.drawable.rose_3);
					else 
						iv.setImageResource(R.drawable.rose_2);
					break;
				}
	}
	
	public void init_earth(){
		
		for(int key=1;key<=12;key++){
			land=ds.findLandInfo(key);
			if(land.get_ifopen()==1){
				if(land.get_ifplant()==1){
					switch(key){
					case 1:
						plant_on_earth(imageview_plant_1, key, land.get_plantkind());
						break;
					case 2:
						plant_on_earth(imageview_plant_2, key, land.get_plantkind());
						break;
					case 3:
						plant_on_earth(imageview_plant_3, key, land.get_plantkind());
						break;
					case 4:
						plant_on_earth(imageview_plant_4, key, land.get_plantkind());
						break;
					case 5:
						plant_on_earth(imageview_plant_5, key, land.get_plantkind());
						break;
					case 6:
						plant_on_earth(imageview_plant_6, key, land.get_plantkind());
						break;
					case 7:
						plant_on_earth(imageview_plant_7, key, land.get_plantkind());
						break;
					case 8:
						plant_on_earth(imageview_plant_8, key, land.get_plantkind());
						break;
					case 9:
						plant_on_earth(imageview_plant_9, key, land.get_plantkind());
						break;
					case 10:
						land=ds.findLandInfo(10);
						if(land.get_ifopen()==1)imageview_earth_10.setImageResource(R.drawable.earth1);
						plant_on_earth(imageview_plant_10, key, land.get_plantkind());
						break;
					case 11:
						land=ds.findLandInfo(11);
						if(land.get_ifopen()==1)imageview_earth_11.setImageResource(R.drawable.earth1);
						plant_on_earth(imageview_plant_11, key, land.get_plantkind());
						break;
					case 12:
						land=ds.findLandInfo(12);
						if(land.get_ifopen()==1)imageview_earth_12.setImageResource(R.drawable.earth1);
						plant_on_earth(imageview_plant_12, key, land.get_plantkind());
						break;
					}
					
				}
				else{}
			}
			else{}
		}
	}
	
	public void plant_small(ImageView iv, int key, int kind){
		seed = ds.findSeedInfo(kind);
		land = ds.findLandInfo(key);
		plant = ds.findPlantInfo(kind);
		if(seed.get_userhad()>0){
			Toast.makeText(getApplicationContext(), "��ֲ�ɹ�", 500).show();
			switch(kind){
			case 1:
				iv.setImageResource(R.drawable.apple_1);
				break;
			case 2:
				iv.setImageResource(R.drawable.peach_1);
				break;
			case 3:
				iv.setImageResource(R.drawable.watermelon_1);
				break;
			case 4:
				iv.setImageResource(R.drawable.shiliu_1);
				break;
			case 5:
				iv.setImageResource(R.drawable.rose_1);
				break;
			}
			seed.set_userhad(seed.get_userhad()-1);
			land.set_ifplant(1);
			land.set_plantkind(kind);
			land.set_remaintime(plant.get_maturetime());
			ds.updateLandInfo(land);
			ds.updatePlantInfo(plant);
			ds.updateSeedInfo(seed);
		}
		else Toast.makeText(getApplicationContext(), "��û������", 200).show();
	}
	
	public void stage_seed(Land ld,DatabaseService sd,ImageView iv){
		if(ld.get_ifplant()==1&&ld.get_remaintime()>0&&ld.get_landwet()>0){
			plant=sd.findPlantInfo(ld.get_plantkind());
			if(ld.get_landwet()>=60){
				ld.set_remaintime(ld.get_remaintime()-1);
				ld.set_landwet(ld.get_landwet()-1);
			}
			else if(ld.get_landwet()<60){
				ld.set_remaintime(ld.get_remaintime()-0);
				ld.set_landwet(ld.get_landwet()-1);
			}
			sd.updateLandInfo(ld);
			tv_time.setText(null);
			

		
			switch(ld.get_plantkind()){
			case 1:
					if(land.get_remaintime()>=0.7*plant.get_maturetime())
						iv.setImageResource(R.drawable.apple_1);
					else if(land.get_remaintime()<=0.2*plant.get_maturetime())
						iv.setImageResource(R.drawable.apple_3);
					else 
						iv.setImageResource(R.drawable.apple_2);
					break;
			case 2:
				if(land.get_remaintime()>=0.7*plant.get_maturetime())
					iv.setImageResource(R.drawable.peach_1);
				else if(land.get_remaintime()<=0.2*plant.get_maturetime())
					iv.setImageResource(R.drawable.peach_3);
				else 
					iv.setImageResource(R.drawable.peach_2);
				break;
			case 3:
				if(land.get_remaintime()>=0.7*plant.get_maturetime())
					iv.setImageResource(R.drawable.watermelon_1);
				else if(land.get_remaintime()<=0.2*plant.get_maturetime())
					iv.setImageResource(R.drawable.watermelon_3);
				else 
					iv.setImageResource(R.drawable.watermelon_2);
				break;
			case 4:
				if(land.get_remaintime()>=0.7*plant.get_maturetime())
					iv.setImageResource(R.drawable.shiliu_1);
				else if(land.get_remaintime()<=0.2*plant.get_maturetime())
					iv.setImageResource(R.drawable.shiliu_3);
				else 
					iv.setImageResource(R.drawable.shiliu_2);
				break;
			case 5:
				if(land.get_remaintime()>=0.7*plant.get_maturetime())
					iv.setImageResource(R.drawable.rose_1);
				else if(land.get_remaintime()<=0.2*plant.get_maturetime())
					iv.setImageResource(R.drawable.rose_3);
				else 
					iv.setImageResource(R.drawable.rose_2);
				break;
				
			}
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.game_map, menu);
		return true;
	}

}
