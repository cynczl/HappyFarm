package com.example.happyfarm;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends Activity {
	Context context;
	private static HomeActivity homeactivity;
	public static HomeActivity get_obj(){
		return homeactivity;
	}
	private User user;
	private Plant plant;
	private Seed seed;
	private Land land;
	private DatabaseService ds; 
	
	private ImageView imageview_btn_quit;
	private ImageView imageview_seed;
	private ImageView imageview_plant;
	private ImageView imageview_seed_apple;
	private ImageView imageview_seed_waterm;
	private ImageView imageview_seed_peach;
	private ImageView imageview_seed_shiliu;
	private ImageView imageview_seed_jinkela;
	private ImageView imageview_seed_rose;
	private ImageView imageview_sell_apple;
	private ImageView imageview_sell_peach;
	private ImageView imageview_sell_watermelon;
	private ImageView imageview_sell_shiliu;
	private ImageView imageview_sell_rose;
	
	
	
	private TextView tv_money;
	private TextView tv_apple;
	private TextView tv_peach;
	private TextView tv_watermelon;
	private TextView tv_shiliu;
	private TextView tv_rose;
	private TextView tv_jinkela;
	private CharSequence str;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	
		//ȥ�����ںͱ���
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        //ȫ����ʾ
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //���ú���
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);	
        setContentView(R.layout.activity_home);
        if(GameMapActivity.get_obj()!=null){
   //     	GameMapActivity.get_obj().finish();
        }
        context=HomeActivity.this;
        ds = new DatabaseService(context);
		ds.createUserTable();
		ds.createSeedTable();
		ds.createPlantTable();
		user=ds.findUserInfo(1);
		
		
		
        imageview_btn_quit=(ImageView)findViewById(R.id.btn_quit);
        imageview_plant=(ImageView)findViewById(R.id.plant);
        imageview_seed_apple=(ImageView)findViewById(R.id.apple);
        imageview_seed_waterm=(ImageView)findViewById(R.id.waterm);
        imageview_seed_peach=(ImageView)findViewById(R.id.peach);
        imageview_seed_rose=(ImageView)findViewById(R.id.meigui);
        imageview_seed_shiliu=(ImageView)findViewById(R.id.shiliu);
        imageview_seed_jinkela=(ImageView)findViewById(R.id.jinkela);
        imageview_seed=(ImageView)findViewById(R.id.seed);
        imageview_sell_apple=(ImageView)findViewById(R.id.sell_apple);
        imageview_sell_peach=(ImageView)findViewById(R.id.sell_peach);
        imageview_sell_watermelon=(ImageView)findViewById(R.id.sell_watermelon);
        imageview_sell_shiliu=(ImageView)findViewById(R.id.imageview_shiliu);
        imageview_sell_rose=(ImageView)findViewById(R.id.sell_rose);
    

        
        
        tv_money=(TextView)findViewById(R.id.home_money);
        tv_apple=(TextView)findViewById(R.id.et_apple);
        tv_peach=(TextView)findViewById(R.id.et_peach);
        tv_watermelon=(TextView)findViewById(R.id.et_watermelon);
        tv_shiliu=(TextView)findViewById(R.id.et_shiliu);
        tv_rose=(TextView)findViewById(R.id.et_rose);
        tv_jinkela=(TextView)findViewById(R.id.et_jinkela);
        
       
        
        set_money(user.get_money());
        set_init();
        
        imageview_plant.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		set_anti_init();
        		imageview_seed_apple.setImageResource(R.drawable.apple);
        		imageview_seed_waterm.setImageResource(R.drawable.watermelon);
        		imageview_seed_peach.setImageResource(R.drawable.peach);
        		imageview_seed_rose.setImageResource(R.drawable.rose);
        		imageview_seed_shiliu.setImageResource(R.drawable.shiliu);
        		
        	}
        });
        imageview_seed.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		set_init();
        		imageview_seed_apple.setImageResource(R.drawable.seed_apple);
        		imageview_seed_waterm.setImageResource(R.drawable.seed_watermelon);
        		imageview_seed_peach.setImageResource(R.drawable.seed_peach);
        		imageview_seed_rose.setImageResource(R.drawable.seed_rose);
        		imageview_seed_shiliu.setImageResource(R.drawable.seed_shiliu);
        	}
        });
        imageview_btn_quit.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		Intent intent=new Intent(HomeActivity.this,GameMapActivity.class);
       // 		startActivity(intent);
        		HomeActivity.this.finish();
        	}
        });
        imageview_sell_apple.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		plant=ds.findPlantInfo(1);
        		if(plant.get_userhad()>0){
        			plant.set_userhad(plant.get_userhad()-1);
        			user.set_money(plant.get_sellprice()+user.get_money());
        			int money=user.get_money();
					set_money(money);
					
        			ds.updateUserInfo(user);
        			ds.updatePlantInfo(plant);
        			num_dis(ds.findPlantInfo(1));
        			Toast.makeText(context, "���۳ɹ�", 500).show();
        		}
        		else Toast.makeText(context, "�������������Ŷ", 500).show();
        	}
        });
        imageview_sell_peach.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		plant=ds.findPlantInfo(2);
        		if(plant.get_userhad()>0){
        			plant.set_userhad(plant.get_userhad()-1);
        			user.set_money(plant.get_sellprice()+user.get_money());
        			int money=user.get_money();
					set_money(money);
					 
        			ds.updateUserInfo(user);
        			ds.updatePlantInfo(plant);
        			num_dis(ds.findPlantInfo(2));
        			Toast.makeText(context, "���۳ɹ�", 500).show();
        		}
        		else Toast.makeText(context, "�������������Ŷ", 500).show();
        	}
        });
        imageview_sell_watermelon.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		plant=ds.findPlantInfo(3);
        		if(plant.get_userhad()>0){
        			plant.set_userhad(plant.get_userhad()-1);
        			user.set_money(plant.get_sellprice()+user.get_money());
        			int money=user.get_money();
					set_money(money);
					
        			ds.updateUserInfo(user);
        			ds.updatePlantInfo(plant); 
        			num_dis(ds.findPlantInfo(3));
        			Toast.makeText(context, "���۳ɹ�", 500).show();
        		}
        		else Toast.makeText(context, "�������������Ŷ", 500).show();
        	}
        });
        imageview_sell_shiliu.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		plant=ds.findPlantInfo(4);
        		if(plant.get_userhad()>0){
        			plant.set_userhad(plant.get_userhad()-1);
        			user.set_money(plant.get_sellprice()+user.get_money());
        			int money=user.get_money();
					set_money(money);

        			ds.updateUserInfo(user);
        			ds.updatePlantInfo(plant);					
        			num_dis(ds.findPlantInfo(4));
        			Toast.makeText(context, "���۳ɹ�", 500).show();
        		}
        		else Toast.makeText(context, "�������������Ŷ", 500).show();
        	}
        });
        imageview_sell_rose.setOnClickListener(new OnClickListener(){
        	@Override
        	public void onClick(View v){
        		plant=ds.findPlantInfo(5);
        		if(plant.get_userhad()>0){
        			plant.set_userhad(plant.get_userhad()-1);
        			user.set_money(plant.get_sellprice()+user.get_money());
        			int money=user.get_money();
					set_money(money);
					 
        			ds.updateUserInfo(user);
        			ds.updatePlantInfo(plant);
        			num_dis(ds.findPlantInfo(5));
        			Toast.makeText(context, "���۳ɹ�", 500).show();
        		}
        		else Toast.makeText(context, "�������������Ŷ", 500).show();
        	}
        });
	}
	public void set_money(int money){
		tv_money.setText(null);
		str=String.valueOf(money);
		tv_money.setText("��"+str);
	}
	public void num_show(Seed sd){
		switch(sd.get_key()){
		case 1: tv_apple.setText(null);
				tv_apple.setText(String.valueOf(sd.get_userhad()));
				break;
		case 2: tv_peach.setText(null);
				tv_peach.setText(String.valueOf(sd.get_userhad()));
				break;
		case 3: tv_watermelon.setText(null);
				tv_watermelon.setText(String.valueOf(sd.get_userhad()));
				break;
		case 4: tv_shiliu.setText(null);
				tv_shiliu.setText(String.valueOf(sd.get_userhad()));
				break;
		case 5: tv_rose.setText(null);
				tv_rose.setText(String.valueOf(sd.get_userhad()));
				break;
		case 6: tv_jinkela.setText(null);
				tv_jinkela.setText(String.valueOf(sd.get_userhad()));
				break;
		}
	}
	
	public void num_dis(Plant pt){
		switch(pt.get_key()){
			case 1: tv_apple.setText(null);
			tv_apple.setText(String.valueOf(pt.get_userhad()));
		break;
			case 2: tv_peach.setText(null);
			tv_peach.setText(String.valueOf(pt.get_userhad()));
		break;
			case 3: tv_watermelon.setText(null);
			tv_watermelon.setText(String.valueOf(pt.get_userhad()));
		break;
			case 4: tv_shiliu.setText(null);
			tv_shiliu.setText(String.valueOf(pt.get_userhad()));
		break;
			case 5: tv_rose.setText(null);
			tv_rose.setText(String.valueOf(pt.get_userhad()));
		break;
			
		}
	}
	
	public void set_init(){
		imageview_sell_apple.setAlpha(0f);
        set_unpress(imageview_sell_apple);
        imageview_sell_peach.setAlpha(0f);
        set_unpress(imageview_sell_peach);
        imageview_sell_watermelon.setAlpha(0f);
        set_unpress(imageview_sell_watermelon);
        imageview_sell_shiliu.setAlpha(0f);
        set_unpress(imageview_sell_shiliu);
        imageview_sell_rose.setAlpha(0f);
        set_unpress(imageview_sell_rose);
   
        
        num_show(ds.findSeedInfo(1));
        num_show(ds.findSeedInfo(2));
        num_show(ds.findSeedInfo(3));
        num_show(ds.findSeedInfo(4));
        num_show(ds.findSeedInfo(5));
        num_show(ds.findSeedInfo(6));
	}
	public void set_anti_init(){
		imageview_sell_apple.setAlpha(1f);
        set_press(imageview_sell_apple);
        imageview_sell_peach.setAlpha(1f);
        set_press(imageview_sell_peach);
        imageview_sell_watermelon.setAlpha(1f);
        set_press(imageview_sell_watermelon);
        imageview_sell_shiliu.setAlpha(1f);
        set_press(imageview_sell_shiliu);
        imageview_sell_rose.setAlpha(1f);
        set_press(imageview_sell_rose);
        num_dis(ds.findPlantInfo(1));
        num_dis(ds.findPlantInfo(2));
        num_dis(ds.findPlantInfo(3));
        num_dis(ds.findPlantInfo(4));
        num_dis(ds.findPlantInfo(5));
       
	}
	public void set_unpress(ImageView iv){
		iv.setPressed(false);
		iv.setClickable(false);
	}
	public void set_press(ImageView iv){
		iv.setPressed(true);
		iv.setClickable(true);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

}
