package com.example.happyfarm;

import com.example.happyfarm.R;

import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.view.Menu;
import android.view.Window;
import android.view.WindowManager;
import android.widget.VideoView;

public class MainActivity extends Activity {

	private static MainActivity mainactivity;
	public static MainActivity get_obj(){
		return mainactivity;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//ȥ�����ںͱ���
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        //ȫ����ʾ
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //���ú���
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setContentView(R.layout.activity_main);
		mainactivity=this;
		final VideoView videoview=(VideoView)findViewById(R.id.vv_logo);
        String uri = "android.resource://" + getPackageName() + "/" + R.raw.fisssh;
        videoview.setVideoURI(Uri.parse(uri));

 	    videoview.start();
		videoview.setOnCompletionListener(new MediaPlayer.OnCompletionListener()
	    {
		     @Override
		     public void onCompletion(MediaPlayer mp)
		     {
		    	 Intent intent = new Intent( mainactivity, WellcomeActivity.class);
		    	 startActivity(intent);
		     }
		    });
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

} 
