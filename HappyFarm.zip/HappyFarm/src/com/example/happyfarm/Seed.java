package com.example.happyfarm;

public class Seed {
	private int key;
	private String seed_name;
	private int seed_buyprice;
	private int user_had;
	
	public int get_key(){
		return key;
	}
	public void set_key(int num){
		this.key = num;
	}
	public String get_name(){
		return seed_name;
	}
	public void set_name(String str){
		this.seed_name = str;
	}
	public int get_buyprice(){
		return seed_buyprice;
	}
	public void set_buyprice(int price){
		this.seed_buyprice = price;
	}
	public int get_userhad(){
		return user_had;
	}
	public void set_userhad(int num){
		this.user_had = num;
	}
}
