package com.example.happyfarm;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ShopActivity extends Activity {
	Context context;
	private static ShopActivity shopactivity;
	public static ShopActivity get_obj(){
		return shopactivity;
	}
	private User user;
	private Plant plant;
	private Seed seed;
	private Land land;
	private DatabaseService ds; 
	private ImageView imageview_btn_x;
	private ImageView imageview_buy_1;
	private ImageView imageview_buy_2;
	private ImageView imageview_buy_3;
	private ImageView imageview_buy_4;
	private ImageView imageview_buy_5;
	private ImageView imageview_buy_6;
	private TextView tv_money;
	private CharSequence str;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//ȥ�����ںͱ���
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        //ȫ����ʾ
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //���ú���
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setContentView(R.layout.activity_shop);
		if(GameMapActivity.get_obj()!=null){
//			GameMapActivity.get_obj().finish();
		}
		shopactivity=this;
		context=ShopActivity.this;
		ds = new DatabaseService(context);
		ds.createUserTable();
		ds.createSeedTable();
		user=ds.findUserInfo(1);
		
		imageview_btn_x=(ImageView)findViewById(R.id.btn_x);
		tv_money=(TextView)findViewById(R.id.money_show);
		imageview_buy_1=(ImageView)findViewById(R.id.buy1);
		imageview_buy_2=(ImageView)findViewById(R.id.buy2);
		imageview_buy_3=(ImageView)findViewById(R.id.buy3);
		imageview_buy_4=(ImageView)findViewById(R.id.buy4);
		imageview_buy_5=(ImageView)findViewById(R.id.buy5);
		imageview_buy_6=(ImageView)findViewById(R.id.buy6);
		
		set_money(user.get_money());
		
		
		imageview_btn_x.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				Intent intent=new Intent(ShopActivity.this,GameMapActivity.class);
		//		startActivity(intent);
				ShopActivity.this.finish();
			}
		});
		//1
		imageview_buy_1.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
	
		
				seed=ds.findSeedInfo(1);
				
				if(user.get_money()>=seed.get_buyprice()){
					user.set_money(user.get_money()-seed.get_buyprice());
					seed.set_userhad(seed.get_userhad()+1);
					int money=user.get_money();
					set_money(money);
					ds.updateSeedInfo(seed);
					ds.updateUserInfo(user);
					Toast.makeText(context, "����ɹ�", 200).show();
				}
				else Toast.makeText(getApplicationContext(), "���꣬���ǲ�֧������Ӵ", 200).show();
				
			}
		});
		imageview_buy_2.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				seed=ds.findSeedInfo(3);
				if(user.get_money()>=seed.get_buyprice()){
					user.set_money(user.get_money()-seed.get_buyprice());
					seed.set_userhad(seed.get_userhad()+1);
					int money=user.get_money();
					set_money(money);
					ds.updateSeedInfo(seed);
					ds.updateUserInfo(user);
					Toast.makeText(context, "����ɹ�", 200).show();
				}
				else Toast.makeText(getApplicationContext(), "���꣬���ǲ�֧������Ӵ", 200).show();
			}
		});
		imageview_buy_3.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				seed=ds.findSeedInfo(4);
				if(user.get_money()>=seed.get_buyprice()){
					user.set_money(user.get_money()-seed.get_buyprice());
					seed.set_userhad(seed.get_userhad()+1);
					int money=user.get_money();
					set_money(money);
					ds.updateSeedInfo(seed);
					ds.updateUserInfo(user);
					Toast.makeText(context, "����ɹ�", 200).show();
				}
				else Toast.makeText(getApplicationContext(), "���꣬���ǲ�֧������Ӵ", 200).show();
			}
		});
		imageview_buy_4.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				seed=ds.findSeedInfo(2);
				if(user.get_money()>=seed.get_buyprice()){
					user.set_money(user.get_money()-seed.get_buyprice());
					seed.set_userhad(seed.get_userhad()+1);
					int money=user.get_money();
					set_money(money);
					ds.updateSeedInfo(seed);
					ds.updateUserInfo(user);
					Toast.makeText(context, "����ɹ�", 200).show();
				}
				else Toast.makeText(getApplicationContext(), "���꣬���ǲ�֧������Ӵ", 200).show();
			}
		});
		imageview_buy_5.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				seed=ds.findSeedInfo(5);
				if(user.get_money()>=seed.get_buyprice()){
					user.set_money(user.get_money()-seed.get_buyprice());
					seed.set_userhad(seed.get_userhad()+1);
					int money=user.get_money();
					set_money(money);
					ds.updateSeedInfo(seed);
					ds.updateUserInfo(user);
					Toast.makeText(context, "����ɹ�", 200).show();
				}
				else Toast.makeText(getApplicationContext(), "���꣬���ǲ�֧������Ӵ", 200).show();
			}
		});
		imageview_buy_6.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				seed=ds.findSeedInfo(6);
				if(user.get_money()>=seed.get_buyprice()){
					user.set_money(user.get_money()-seed.get_buyprice());
					seed.set_userhad(seed.get_userhad()+1);
					int money=user.get_money();
					set_money(money);
					ds.updateSeedInfo(seed);
					ds.updateUserInfo(user);
					Toast.makeText(context, "����ɹ�", 200).show();
				}
				else Toast.makeText(getApplicationContext(), "���꣬���ǲ�֧������Ӵ", 200).show();
			}
			
		});
		
	}

	
	public void set_money(int money){
		tv_money.setText(null);
		str=String.valueOf(money);
		tv_money.setText("��"+str);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.shop, menu);
		return true;
	}

}
