package com.example.happyfarm;

public class User {
	private int key;
	private String user_id;
	private int user_money;
	
	public int get_key(){
		return key;
	}
	public void set_key(int num){
		this.key = num;
	}
	public String get_id(){
		return user_id;				
	}
	public void set_id(String id){
		this.user_id = id;
	}
	public int get_money(){
		return user_money;
	}
	public void set_money(int money){
		this.user_money = money;
	}
	public void change_money(int chg){
		this.user_money += chg;
	}
}
