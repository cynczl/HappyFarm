package com.example.happyfarm;






import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View.OnClickListener;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.Toast;

public class WellcomeActivity extends Activity {

	private static WellcomeActivity wellcomeactivity;
	public static WellcomeActivity get_obj(){
		return wellcomeactivity;
	}
	Context context;
	private ImageView imageview_new;
	private ImageView imageview_load;
//	private Plant pp;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//ȥ�����ںͱ���
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        //ȫ����ʾ
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //���ú���
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setContentView(R.layout.activity_wellcome);
		
		wellcomeactivity=this;
		if(MainActivity.get_obj()!=null){
			MainActivity.get_obj().finish();
		}
		final Intent intent=new Intent(this,GameMapActivity.class);
		imageview_load=(ImageView)findViewById(R.id.continue_game);
		imageview_new=(ImageView)findViewById(R.id.new_game);
	
		flash(imageview_load);
		flash(imageview_new);
		context=WellcomeActivity.this;
		//�������ݿ�
		//���ݿ��ʼ��
		//�û�
		
		DatabaseService ds = new DatabaseService(context);
			
		ds.createUserTable();
		
		
		if(ds.findUserInfo(1)==null){
	
			
		User user = new User();
		user.set_key(1);
		user.set_id("ouc");
		user.set_money(100);
		ds.saveUserInfo(user);
		//ֲ��
		ds.createPlantTable();
		
		Plant apple = new Plant();
		apple.set_key(1);
		apple.set_name("apple");
		apple.set_productnum(6);
		apple.set_maturetime(60);
		apple.set_sellprice(5);
		apple.set_userhad(1);
		ds.savePlantInfo(apple);
		//
		Plant peach = new Plant();
		peach.set_key(2);
		peach.set_name("peach");
		peach.set_productnum(7);
		peach.set_maturetime(70);
		peach.set_sellprice(6);
		peach.set_userhad(0);
		ds.savePlantInfo(peach);
		
		//
		Plant watermelon = new Plant();
		watermelon.set_key(3);
		watermelon.set_name("watermelon");
		watermelon.set_productnum(2);
		watermelon.set_maturetime(90);
		watermelon.set_sellprice(15);
		watermelon.set_userhad(1);
		ds.savePlantInfo(watermelon);
		//
		Plant shiliu = new Plant();
		shiliu.set_key(4);
		shiliu.set_name("shiliu");
		shiliu.set_productnum(6);
		shiliu.set_maturetime(40);
		shiliu.set_sellprice(8);
		shiliu.set_userhad(0);
		ds.savePlantInfo(shiliu);
		//
		Plant rose = new Plant();
		rose.set_key(5);
		rose.set_name("rose");
		rose.set_productnum(3);
		rose.set_maturetime(135);
		rose.set_sellprice(30);
		rose.set_userhad(0);
		ds.savePlantInfo(rose);
		
		//����
		ds.createSeedTable();
		
		Seed seed_apple = new Seed();
		seed_apple.set_key(1);
		seed_apple.set_name("seed_apple");
		seed_apple.set_buyprice(10);
		seed_apple.set_userhad(0);
		ds.saveSeedInfo(seed_apple);
		//
		Seed seed_peach = new Seed();
		seed_peach.set_key(2);
		seed_peach.set_name("seed_peach");
		seed_peach.set_buyprice(15);
		seed_peach.set_userhad(0);
		ds.saveSeedInfo(seed_peach);
		//
		Seed seed_watermelon = new Seed();
		seed_watermelon.set_key(3);
		seed_watermelon.set_name("seed_watermelon");
		seed_watermelon.set_buyprice(23);
		seed_watermelon.set_userhad(0);
		ds.saveSeedInfo(seed_watermelon);
		//
		Seed seed_shiliu = new Seed();
		seed_shiliu.set_key(4);
		seed_shiliu.set_name("shiliu");
		seed_shiliu.set_buyprice(20);
		seed_shiliu.set_userhad(0);
		ds.saveSeedInfo(seed_shiliu);
		//
		Seed seed_rose = new Seed();
		seed_rose.set_key(5);
		seed_rose.set_name("rose");
		seed_rose.set_buyprice(38);
		seed_rose.set_userhad(0);
		ds.saveSeedInfo(seed_rose);
		//
		Seed seed_jinkela = new Seed();
		seed_jinkela.set_key(6);
		seed_jinkela.set_name("jinkela");
		seed_jinkela.set_buyprice(12);
		seed_jinkela.set_userhad(0);
		ds.saveSeedInfo(seed_jinkela);
		//ʳ��
		ds.createFooddTable();
		
		Food flower_pie = new Food();
		flower_pie.set_key(1);
		flower_pie.set_name("flower_pie");
		flower_pie.set_sellprice(100);
		flower_pie.set_userhad(0);
		ds.saveFoodInfo(flower_pie);
		
		//����
		ds.createLandTable();
		//
		Land land_1=new Land();
		land_1.set_key(1);
		land_1.set_ifopen(1);
		land_1.set_ifplant(0);
		land_1.set_landwet(100);
		land_1.set_remaintime(0);
		land_1.set_plantkind(0);
		ds.saveLandInfo(land_1);
		//
		Land land_2 = new Land();
		land_2.set_key(2);
		land_2.set_ifopen(1);
		land_2.set_ifplant(0);
		land_2.set_landwet(100);
		land_2.set_remaintime(0);
		land_2.set_plantkind(0);
		ds.saveLandInfo(land_2);
		//
		Land land_3 = new Land();
		land_3.set_key(3);
		land_3.set_ifopen(1);
		land_3.set_ifplant(0);
		land_3.set_landwet(100);
		land_3.set_remaintime(0);
		land_3.set_plantkind(0);
		ds.saveLandInfo(land_3);
		//
		Land land_4 = new Land();
		land_4.set_key(4);
		land_4.set_ifopen(1);
		land_4.set_ifplant(0);
		land_4.set_landwet(100);
		land_4.set_remaintime(0);
		land_4.set_plantkind(0);
		ds.saveLandInfo(land_4);
		//
		Land land_5 = new Land();
		land_5.set_key(5);
		land_5.set_ifopen(1);
		land_5.set_ifplant(0);
		land_5.set_landwet(100);
		land_5.set_remaintime(0);
		land_5.set_plantkind(0);
		ds.saveLandInfo(land_5);
		//
		Land land_6 = new Land();
		land_6.set_key(6);
		land_6.set_ifopen(1);
		land_6.set_ifplant(0);
		land_6.set_landwet(100);
		land_6.set_remaintime(0);
		land_6.set_plantkind(0);
		ds.saveLandInfo(land_6);
		//
		Land land_7 = new Land();
		land_7.set_key(7);
		land_7.set_ifopen(1);
		land_7.set_ifplant(0);
		land_7.set_landwet(100);
		land_7.set_remaintime(0);
		land_7.set_plantkind(0);
		ds.saveLandInfo(land_7);
		//
		Land land_8 = new Land();
		land_8.set_key(8);
		land_8.set_ifopen(1);
		land_8.set_ifplant(0);
		land_8.set_landwet(100);
		land_8.set_remaintime(0);
		land_8.set_plantkind(0);
		ds.saveLandInfo(land_8);
		//
		Land land_9 = new Land();
		land_9.set_key(9);
		land_9.set_ifopen(1);
		land_9.set_ifplant(0);
		land_9.set_landwet(100);
		land_9.set_remaintime(0);
		land_9.set_plantkind(0);
		ds.saveLandInfo(land_9);
		//
		Land land_10 = new Land();
		land_10.set_key(10);
		land_10.set_ifopen(0);
		land_10.set_ifplant(0);
		land_10.set_landwet(100);
		land_10.set_remaintime(0);
		land_10.set_plantkind(0);
		ds.saveLandInfo(land_10);
		//
		Land land_11 = new Land();
		land_11.set_key(11);
		land_11.set_ifopen(0);
		land_11.set_ifplant(0);
		land_11.set_landwet(100);
		land_11.set_remaintime(0);
		land_11.set_plantkind(0);
		ds.saveLandInfo(land_11);
		//
		Land land_12 = new Land();
		land_12.set_key(12);
		land_12.set_ifopen(0);
		land_12.set_ifplant(0);
		land_12.set_landwet(100);
		land_12.set_remaintime(0);
		land_12.set_plantkind(0);
		ds.saveLandInfo(land_12);
		}
		//�������ݿ�
		DatabaseService ds1 = new DatabaseService(context);
//		pp = ds1.findPlantInfo(2);
		imageview_load.setOnClickListener(new OnClickListener(){
			@Override
        	public void onClick(View v){
				
//        		Toast.makeText(getApplicationContext(), pp.get_name(), Toast.LENGTH_SHORT).show();
				startActivity(intent);
        	}
		});
		
		imageview_new.setOnClickListener(new OnClickListener(){
			@Override
        	public void onClick(View v){
				
				startActivity(intent);
        	}
		});
	}

	void flash(ImageView iv){
		AlphaAnimation alphaAnimation = new AlphaAnimation(0.1f, 1.0f);    
		alphaAnimation.setDuration(1000);    
		alphaAnimation.setRepeatCount(0);    
//		alphaAnimation.setRepeatMode(Animation.REVERSE);    
		iv.setAnimation(alphaAnimation);    
		alphaAnimation.start();    
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.wellcome, menu);
		return true;
	}

}
